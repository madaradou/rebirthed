#ifndef ASSETS_H
#define ASSETS_H

#include "menu.h"

#define WINDOW_W 1920
#define WINDOW_H 1080



#endif // ASSETS_H